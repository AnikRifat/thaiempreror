<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />    
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Send Message | Namaste Swanley</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />    
</head>
<body style="background: #eee;">

	<div style="background: #fff none repeat scroll 0 0; border-top: 1px solid; margin: 0 auto 80px;width: 960px; ">
	<div style="margin-left: -15px;margin-right: -15px; overflow: hidden;">
		<div style="min-height: 1px;padding-left: 15px;padding-right: 15px;position: relative;width: 28.3333%; float: left;">
			<img src="http://cms.schaferlogistics.com/images/bwschaferlogo.gif" alt="Schafer Logistics Logo" style="margin-left: 45px; margin-top: 15px;">
		</div>
		<div style="min-height: 1px;padding-left: 15px;padding-right: 15px;position: relative;width: 29.3333%; float: left;">
			<p style="margin: 0;padding: 0;text-align: center;"><?php echo date('m/d/Y', time()	); ?> &nbsp; &nbsp;
			</p>
			<p id="ticket-number" style="font-weight: bold;border: 1px solid #333;padding: 5px;text-align: center;">name of custoemr</p>
		</div>
		<div style="min-height: 1px;padding-left: 15px;padding-right: 15px;position: relative;width: 30.3333%; float: left;">
			<div style="border-bottom: 2px solid #222;position: relative;">
				<h3 style="margin: 0;padding: 0;text-align: center;">text</h3>
				<p style="border: 1px solid #222;width:10px; padding: 0 5px;position: absolute;right: 20px;text-align: right;top: -16px;">text</p>
			</div>
			<div>
				<h3 style="margin: 0;padding: 0;text-align: center;">text</h3>
			</div>
		</div>
	</div>
</div>

</body>
</html>