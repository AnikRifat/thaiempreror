<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FoodSubCat extends Model
{
    //
}
