<!--  JAVASCRIPT -->
<script type="text/javascript" src="<?php echo e('/js/home/jquery.min.js'); ?>"></script>
<!-- Modernizr JS --> 
<script type="text/javascript" src="<?php echo e('/js/home/modernizr-2.6.2.min.js'); ?>"></script>
<!--Bootatrap JS-->
<script type="text/javascript" src="<?php echo e('/js/home/bootstrap.min.js'); ?>"></script>
<!-- Animate js -->
<script type="text/javascript" src="<?php echo e('/js/home/wow.min.js'); ?>"></script>
<!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
<script type="text/javascript" src="<?php echo e('/js/home/jquery.themepunch.tools.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo e('/js/home/jquery.themepunch.revolution.min.js'); ?>"></script>

<!-- Fancy Box JS -->
<script type="text/javascript" src="<?php echo e('/js/home/jquery.fancybox.min.js'); ?>"></script>
<!-- OWL CAROUSEL   -->
<script type="text/javascript" src="<?php echo e('/js/home/owl.carousel.min.js'); ?>"></script> 
<!-- Offcanvas -->
<script type="text/javascript" src="<?php echo e('/js/home/jquery.mmenu.min.all.js'); ?>"></script>
<!-- Gallery Shuffle Js -->
<script type="text/javascript" src="<?php echo e('/js/home/jquery.shuffle.min.js'); ?>"></script>

<!-- jQuery UI -->
<script type="text/javascript" src="<?php echo e('/js/home/jquery-ui.min.js'); ?>"></script>

<!-- Validation -->
<script type="text/javascript" src="<?php echo e('/js/home/validation.js'); ?>"></script>

<!-- Smooth Scroll JS -->
<script src="<?php echo e('/js/home/scrolling-nav.js'); ?>"></script>

<!-- Tweetie JS  -->
<script type="text/javascript" src="<?php echo e('/js/home/tweetie.min.js'); ?>"></script>

<!-- Google Map PopUp -->
<script src="https://maps.googleapis.com/maps/api/js"></script>


<!-- Google Map Contact -->


<!-- Css Preseter -->
<script type="text/javascript" src="<?php echo e('/js/home/preset.js'); ?>"></script>

<!-- Custom script --> 
<script type="text/javascript" src="<?php echo e('/js/home/custom.js'); ?>"></script>