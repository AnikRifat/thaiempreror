<?php $__env->startSection('title', 'Showing Food Categories'); ?>
<?php $__env->startSection('content'); ?>
    
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-icon" data-background-color="purple">
                <i class="material-icons">assignment</i>
            </div>
            <div class="card-content">
                <div class="col-md-6">
                    <h4 class="card-title">Showing All Categories</h4>
                </div>
                <div class="col-md-5 text-right">
                    <a class="text-success btn-icon" target="_blank" href="/admin/create_category"><i class="material-icons">add_box</i></a>
                </div>
                <div class="toolbar">
                    <!--        Here you can write extra buttons/actions for the toolbar              -->
                </div>
                <div class="material-datatables">
                    <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Category ID</th>
                                <th>Category Name</th>
                                <th>Category Slug</th>
                                <th>Category Type</th>
                                <th>Created At</th>
                                <th class="disabled-sorting text-right">Actions</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>#</th>
                                <th>Category ID</th>
                                <th>Category Name</th>
                                <th>Category Slug</th>
                                <th>Category Type</th>
                                <th>Created At</th>
                                <th class="text-right">Actions</th>
                            </tr>
                        </tfoot>
                        <tbody>

                            <?php $r = 0; ?>

                            <?php $__currentLoopData = $foodcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php $r++; ?>

                            <tr>
                                <td><?php echo e($r); ?></td>
                                <td><?php echo e($foodcat->cat_id); ?></td>
                                <td><?php echo e($foodcat->cat_name); ?></td>
                                <td><?php echo e($foodcat->cat_slug); ?></td>
                                <td><?php echo e($foodcat->cat_type); ?></td>
                                <td title="<?php echo e(date('H:i:s', strtotime($foodcat->created_at))); ?>"><?php echo e(date('m/d/Y', strtotime($foodcat->created_at))); ?></td>
                                <td class="text-right">
                                    <a href="/admin/foodcat/<?php echo e($foodcat->id); ?>/edit" class="btn btn-simple btn-info btn-icon"><i class="material-icons">dvr</i></a>
                                    <a href="/admin/foodcat/<?php echo e($foodcat->id); ?>/edit" class="btn btn-simple btn-warning btn-icon" title="Edit the record"><i class="material-icons">mode_edit</i></a>

    <?php if(Auth::guard('admin')->user()->user_role == 'SUPER-ADMIN'): ?>

    <a href="#" class="btn btn-simple btn-danger btn-icon" title="Delete Food Categories" onclick="document.getElementById('target<?php echo e($r); ?>').style.display = 'block';"><i class="material-icons">delete</i></a>

    <?php echo e(Form::open(['route' => ['admin.foodcat.delete', $foodcat->id], 'method' => 'DELETE', 'class' => 'button-form pull-left'])); ?>

    <div id="target<?php echo e($r); ?>" class="swal2-modal swal2-show delete-alert">
        <h2>Are you sure?</h2>
        <div class="swal2-content" style="display: block;">You want to delete this!</div>
        <hr class="swal2-spacer" style="display: block;">
        <button type="submit" class="btn btn-success"><i class="material-icons">check</i></button>
        <button class="btn btn-danger" type="button" onclick="this.parentNode.style.display = 'none';"><i class="material-icons">close</i></button>
    </div>
    <?php echo e(Form::close()); ?>


    <?php endif; ?>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>
            <!-- end content-->
        </div>
        <!--  end card  -->
    </div>
    <!-- end col-md-12 -->
</div>
<!-- end row --> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>