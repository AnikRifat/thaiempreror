<?php $__env->startSection('title', 'reservation'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="container text-center">
    <div class="row">
        <div class="col-md-12">
            <img src="/images/r1.jpg" class="img-fluid m-4" style="
    padding-bottom: 30px;
    padding-top: 30px;
    height: 720px;
    margin: 0px auto;
    width: auto;
" alt=""/>
        </div>
        <div class="col-md-12 mt-3">
              <img src="/images/r2.jpg" class="img-fluid m-4" style="
    padding-bottom: 30px;
    padding-top: 30px;
    height: 720px;
    margin: 0px auto;
    width: auto;
" alt=""/>
        </div>
        </div>
    </div>
    
      
</div>

  <script src="https://www.fbgcdn.com/embedder/js/ewm2.js"defer async ></script></a></li>

>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>