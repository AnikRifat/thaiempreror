            <footer class="footer">
                <div class="container">
                    <nav class="pull-left">
                        <ul>
                            <!--
                            <li><a href="/">Home</a></li>
                            <li><a href="/registration">Register</a></li>
                            <li><a href="/login">Login</a></li>
                            <li><a href="/my_account">My Account</a></li>
                            <li><a href="/help">Help</a></li>
                        -->
                        </ul>
                    </nav>
                    <p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                        <a href="<?php echo e(config('app.url')); ?>"><?php echo e(config('app.name')); ?></a>. All Rights Reserved.
                    </p>
                </div>
            </footer>
        </div>
    </div>